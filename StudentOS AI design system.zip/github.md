repo: Nadokagenou/studentos-ai
branch: main

## Last sync
date: 2026-07-26T04:54:29Z

### Updated in this project
- Recreated all 9 screens of the live app pixel-for-pixel from `index.html` / `style.css` / `app.js` / `engine.js`
- Built a refined pass answering the design critique: Electric Indigo #4F46E5, ambient shadows, layered-slate dark mode, glass chrome, IBM Plex Sans Thai display type, 28px section rhythm
- Added the states the app is missing today: skeleton while AI parses, OCR scanning, empty, celebration, overdue
- Wrote a drop-in `style.css` (same class names) ready to commit over the repo's stylesheet
- Status-bar signal/battery glyphs now come from lucide `icons/signal.svg` + `icons/battery-medium.svg` instead of hand-drawn paths

## Screen map
| Project screen | Repo files |
|---|---|
| StudentOS AI — Current.dc.html · all screens | index.html, style.css, app.js, engine.js |
| Home / Top 3 (hero + next rows) | app.js `renderHome` `heroCard` `nextRow`, engine.js `priorityInfo` `aiHeroWhy`, style.css `.hero` `.nrow` |
| เพิ่มงาน (Scan / voice / paste) | index.html `#scr-scan`, app.js `toggleVoice` `scanFromText` `scanFromPhoto`, style.css `.btn.voice` `.paste-box` |
| ยืนยัน / แก้ไข (AI detected form) | index.html `#scr-form`, app.js `openForm` `setTypePick` `setStarPick`, engine.js `parseAssignment` |
| งานทั้งหมด | app.js `renderTasks` `taskRow`, style.css `.task-row` `.fchip` `.assign-sect` |
| Timeline | app.js `renderTimeline`, engine.js `timelineInsight`, style.css `.tl-*` `.legend` |
| แผนวันนี้ (AI planner) | app.js `renderPlan`, engine.js `buildDayPlan`, style.css `.plan-*` |
| ฉัน (Profile) | app.js `renderProfile` `renderInstallCard`, style.css `.pf-*` |
| Login + Splash | index.html `#scr-login` `#splash`, app.js `loginGoogle` `skipLogin`, style.css `#splash` `.login-*` |
| ติดตั้ง (iOS sheet) | index.html `#installGuide`, app.js `showInstallGuide`, style.css `.ig-*` |
| StudentOS AI — Refined.dc.html | same sources, restyled per uploads/studentos_design_critique.pdf |
| style.css (drop-in v2) | style.css (v1) — every class name preserved |

Icons in the refined pass come from lucide-icons/lucide@main (`icons/*.svg`), MIT.
